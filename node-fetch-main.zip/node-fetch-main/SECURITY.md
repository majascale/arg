# Security Policy

## Reporting a Vulnerability

Please report security issues to `jimmy@warting.se`